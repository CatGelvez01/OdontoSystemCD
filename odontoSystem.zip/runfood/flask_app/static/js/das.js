function ocultarBoton() {
    var boton = document.getElementsByClassName("mi_boton");
    boton.classList.add("oculto");
}